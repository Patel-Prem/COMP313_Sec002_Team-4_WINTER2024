import boto3
import base64


class TranslationService:
    def __init__(self):
        self.client = boto3.client('translate')
        self.polly_client = boto3.client('polly')

    def translate_text(self, text, source_language = 'auto', target_language = 'en'):
        response = self.client.translate_text(
            Text = text,
            SourceLanguageCode = source_language,
            TargetLanguageCode = target_language
        )

        translation = {
            'translatedText': response['TranslatedText'],
            'sourceLanguage': response['SourceLanguageCode'],
            'targetLanguage': response['TargetLanguageCode']
        }

        return translation

    def convert_text_to_audio(self, text):
        response = self.polly_client.synthesize_speech(
            Text=text,
            OutputFormat='mp3',
            VoiceId='your-preferred-voice-id'
        )

        audio_data = response['AudioStream'].read()
        audio_base64 = base64.b64encode(audio_data).decode('utf-8')
        return audio_base64
