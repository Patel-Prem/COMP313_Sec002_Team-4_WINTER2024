import boto3

class PollyService:
    def __init__(self):
        self.polly_client = boto3.client('polly')

    def convert_text_to_audio(self, text):
        response = self.polly_client.synthesize_speech(
            Text=text,
            OutputFormat='mp3',
            VoiceId='Joanna'
        )

        audio_url = response['AudioStream'].get('Location')
        return audio_url
