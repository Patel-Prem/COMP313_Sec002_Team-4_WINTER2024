from chalice import Chalice
from chalice import CORSConfig
from chalicelib import storage_service
from chalicelib import recognition_service
from chalicelib import translation_service
from chalicelib import polly_service

import base64
import json

app = Chalice(app_name='Capabilities')
app.debug = True

# Define CORS configuration
cors_config = CORSConfig(
    allow_origin='*',
    allow_headers=['Content-Type'],
    max_age=600,
    expose_headers=['X-Amz-Date', 'X-Amz-Content-SHA256', 'Authorization', 'X-Amz-Security-Token']
)

# Remove the AWS Polly client initialization here since Chalice will handle it automatically.

storage_location = 'contentcen301297324.aws.ai'
storage_service = storage_service.StorageService(storage_location)
recognition_service = recognition_service.RecognitionService(storage_service)
translation_service = translation_service.TranslationService()
polly_service = polly_service.PollyService()

@app.route('/images', methods=['POST'], cors=True)
def upload_image():
    request_data = json.loads(app.current_request.raw_body)
    file_name = request_data['filename']
    file_bytes = base64.b64decode(request_data['filebytes'])

    image_info = storage_service.upload_file(file_bytes, file_name)

    return image_info

@app.route('/text-to-audio', methods=['POST'], cors=cors_config)
def text_to_audio():
    request_data = json.loads(app.current_request.raw_body)
    text = request_data['text']

    audio_url = polly_service.convert_text_to_audio(text)

    return {'audioUrl': audio_url}


@app.route('/images/{image_id}/translate-text', methods=['POST'], cors=True)
def translate_image_text(image_id):
    request_data = json.loads(app.current_request.raw_body)
    from_lang = request_data['fromLang']
    to_lang = request_data['toLang']

    MIN_CONFIDENCE = 80.0

    text_lines = recognition_service.detect_text(image_id)

    translated_lines = []
    for line in text_lines:
        # check confidence
        if float(line['confidence']) >= MIN_CONFIDENCE:
            translated_line = translation_service.translate_text(line['text'], from_lang, to_lang)
            translated_lines.append({
                'text': line['text'],
                'translation': translated_line,
                'boundingBox': line['boundingBox']
            })
    return translated_lines
