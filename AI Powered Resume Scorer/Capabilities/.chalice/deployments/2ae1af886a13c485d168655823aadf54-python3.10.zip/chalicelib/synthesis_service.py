# chalicelib/synthesis_service.py

import boto3

class SynthesisService:
    def __init__(self):
        self.client = boto3.client('polly')

    def synthesize_speech(self, text, voice_id='Joanna', output_format='mp3'):
        response = self.client.synthesize_speech(
            Text=text,
            OutputFormat=output_format,
            VoiceId=voice_id
        )

        return response['AudioStream'].read()
