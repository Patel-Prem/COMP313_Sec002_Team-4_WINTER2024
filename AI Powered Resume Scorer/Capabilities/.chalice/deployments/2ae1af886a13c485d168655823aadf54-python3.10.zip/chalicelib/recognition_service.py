import boto3


class RecognitionService:
    def __init__(self, storage_service):
        self.client = boto3.client('rekognition')
        self.bucket_name = storage_service.get_storage_location()

    # Add this new method to RecognitionService
    def synthesize_speech(self, text):
        response = self.client.start_speech_synthesis_task(
            OutputFormat='mp3',
            Text=text,
            VoiceId='Joanna'  # You can choose different voices based on your preference
        )
        
        task_id = response['SynthesisTask']['TaskId']
        audio_url = f'https://polly.us-east-1.amazonaws.com/v1/speech/{task_id}.mp3'
        return audio_url


    def detect_text(self, file_name):
        response = self.client.detect_text(
            Image = {
                'S3Object': {
                    'Bucket': self.bucket_name,
                    'Name': file_name
                }
            }
        )

        lines = []
        for detection in response['TextDetections']:
            if detection['Type'] == 'LINE':
                lines.append({
                    'text': detection['DetectedText'],
                    'confidence': detection['Confidence'],
                    'boundingBox': detection['Geometry']['BoundingBox']
                })

        return lines

